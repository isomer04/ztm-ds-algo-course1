# ZeroToMastery Data Structures & Algorithms course

This repo includes all the data structure and algorithm exercises solutions and implementations. 

Inside the `docs/` folder you can also find all the notes I took during the course. 

Everything is a bit chaotic and WIP, I know, but it's not meant to be a full reference, it's just my **Go** version of the course.