package recursion

import (
	"fmt"
	"testing"
)

func TestReverseString(t *testing.T) {
	fmt.Println(ReverseString("say something"))
	fmt.Println(ReverseString("fabio"))
	fmt.Println(ReverseString("stefania"))
}
